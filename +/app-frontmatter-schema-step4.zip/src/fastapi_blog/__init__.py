import os
from typing import Any

import jinja2
from fastapi import FastAPI
from fastapi.templating import Jinja2Templates

from .admin import Admin, add_admin_to_app
from .editor import add_editor_to_app, get_api_router
from .main import add_blog_to_fastapi
from .models import DEFAULT_SCHEMA, FieldSpec, FrontmatterSchema
from .router import get_blog_router


__version__ = "0.8.0"


def setup_fastapi_blog(
    app: FastAPI,
    *,
    posts_dirname: str = "posts",
    include_api: bool = False,
    locales: list[str] = ["en"],
    default_locale: str = "en",
    admin_username: str | None = None,
    admin_password: str | None = None,
    secret_key: str | None = None,
    enable_role_management: bool = False,
    frontmatter_schema: FrontmatterSchema | None = None,
) -> dict[str, Admin]:
    """Configure the blog and admin panel for a FastAPI application.

    `frontmatter_schema` (optional) sets the post fields for the blog, the REST API
    and the admin panel at once. Without it the built-in fields are used.
    """
    # Get credentials from env if not provided
    if admin_username is None:
        admin_username = os.getenv("FASTAPI_BLOG_ADMIN_LOGIN", "admin")
    if admin_password is None:
        admin_password = os.getenv("FASTAPI_BLOG_ADMIN_PASSWORD", "Admin123!")

    add_blog_to_fastapi(
        app,
        posts_dirname=posts_dirname,
        include_api=include_api,
        locales=locales,
        default_locale=default_locale,
        admin_username=admin_username,
        admin_password=admin_password,
        frontmatter_schema=frontmatter_schema,
    )
    return add_admin_to_app(
        app,
        locales=locales,
        default_locale=default_locale,
        admin_username=admin_username,
        admin_password=admin_password,
        secret_key=secret_key,
        enable_role_management=enable_role_management,
        frontmatter_schema=frontmatter_schema,
    )
